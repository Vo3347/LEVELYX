LEVELYX V1 — GitHub Pages Ready

Files:
- index.html — current LEVELYX V1 customization build
- game.html — reusable game detail page used by the game links
- assets/games/ — reserved for future official/authorized game artwork

To publish with GitHub Pages:
1. Create a GitHub repository.
2. Upload index.html, game.html, and the assets folder.
3. In the repository, open Settings -> Pages.
4. Select Deploy from a branch, choose the main branch and / (root), then Save.
5. Open the GitHub Pages URL after deployment.

Important V1 note:
Account, PEX, perks, community posts and customization currently use browser-local storage/prototype logic. They are not yet real secure cross-device accounts or real payment processing.
